package com.wipro.bus.util;

public class InvalidInputException extends Exception {
	public String toString()
	{
		return "Invalid Input";
	}
}
