package com.wipro.carrental.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

	public static Connection getDBConn(){
		try{
		Class.forName("oracle.jdbc.OracleDriver");
		return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","B44575767521","B44575767521");
		//return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl1","scott","tiger");
		}
		catch (Exception e) {
			return null;
		}
	}
}
