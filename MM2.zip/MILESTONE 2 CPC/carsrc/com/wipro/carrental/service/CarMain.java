package com.wipro.carrental.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.wipro.carrental.bean.CarBookingBean;
import com.wipro.carrental.dao.CarBookingDAO;
import com.wipro.carrental.util.DBUtil;

public class CarMain {
	public static void main(String[] args) throws SQLException {
		String sql="select count(*) from ch where d=?";
		PreparedStatement ps=DBUtil.getDBConn().prepareStatement(sql);
		ps.setDate(1, new java.sql.Date(new Date().getTime()));
		ResultSet rs=ps.executeQuery();
		rs.next();
		System.out.println(rs.getInt(1));
	}

	public String bookACar(CarBookingBean cBean){
		try{
			if(cBean==null){
				return "FAILURE";	
			}
			if(cBean.getCustomerName().isEmpty()||cBean.getDateOfHire()==null||cBean.getPhoneNumber().length()<10){
				return "FAILURE";
			}
			if(cBean.getDateOfHire().getTime()<new Date().getTime()){
				return "INVALID DATE FOR BOOKING";
			}
			else{
				CarBookingDAO bookingDAO=new CarBookingDAO();
				int availableCars=bookingDAO.getAvailableCars(cBean.getCarType());
				if(availableCars==0){
					return "NO CARS OF THE GIVEN TYPE AVAILABLE";
				}
				else{
					int avail=bookingDAO.findBookedCarsByDate(cBean.getDateOfHire(), cBean.getCarType());
					if((availableCars-avail)<=0){
						return "NO CARS AVAILABLE ON GIVEN DATE";
					}
					else{
						String s=bookingDAO.getBookingID(cBean.getCarType());
						cBean.setBookingId(s);
						boolean b=bookingDAO.bookACar(cBean);
						if(b){
							return "SUCCESS";
						}
						else{
							return "FAILURE";
						}
					}
				}
			}
		}
		catch (Exception e) {
			return "FAILURE";
		}
	}
	
	public String cancelACar(String bookingId){
		CarBookingDAO bookingDAO=new CarBookingDAO();
		boolean s=bookingDAO.cancelACar(bookingId);
		if(s){
			return "CANCELLED";
		}
		else{
			return "NO SUCH ID EXISTS";
		}
	}
}
