package com.wipro.money.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
public static Connection getDBConn()
{
	Connection con=null;
	try{
		Class.forName("oracle.jdbc.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","B16376742","B16376742");
		System.out.println(con);
	}
	catch(ClassNotFoundException c)
	{
		c.printStackTrace();
	}
	catch(SQLException s)
	{
		s.printStackTrace();
	}
	return con;
}
}
