package com.wipro.money.util;

public class InsufficientBalanceException extends Exception{

	@Override
	public String toString() {
		// write code here
		return "Insufficient Balance";
	}

}
