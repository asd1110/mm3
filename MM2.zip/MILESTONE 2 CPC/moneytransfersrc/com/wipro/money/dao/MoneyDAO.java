package com.wipro.money.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.wipro.money.bean.AccountBean;
import com.wipro.money.bean.TransactionBean;
import com.wipro.money.util.DBUtil;


public class MoneyDAO {
	
	Connection con=DBUtil.getDBConn();
	PreparedStatement ps;
	ResultSet rs;
	
	public boolean validateAccount(String accountno) throws SQLException
	{
		ps=con.prepareStatement("select * from ACCOUNT_TBL where account_number=?");
		ps.setString(1,accountno);
		rs=ps.executeQuery();
		while(rs.next())
		{
			return true;
		}
		
		return false;
	}
	
	
	public float getBalance(String accountnumber) throws SQLException
	{
		
		float balance=0f;
		ps=con.prepareStatement("select * from account_tbl where account_number=?");
		ps.setString(1,accountnumber);
		rs=ps.executeQuery();
		while(rs.next())
		{
			balance= rs.getFloat(4);	
		}
		return balance;
	}  
	
	public boolean updateBalance(String Accountnumber, float amount,String operation) throws SQLException
	{
		
		float bal=getBalance(Accountnumber);
		boolean status=false;
		
		if(operation.equals("deposit"))
		{
			ps=con.prepareStatement("update ACCOUNT_TBL set balance=? where account_number=?");
			ps.setFloat(1,amount+bal);
			ps.setString(2,Accountnumber);
			int u1=ps.executeUpdate();
			if(u1!=0)
			{
				return true;
			}
			else 
				return false;
			
		}
		else if(operation.equals("withdraw"))
		{
			ps=con.prepareStatement("update ACCOUNT_TBL set balance=? where account_number=?");
			ps.setFloat(1,bal-amount);
			ps.setString(2,Accountnumber);
			int u=ps.executeUpdate();
			if(u!=0)
			{
				return true;
			}
			else 
				return false;
			
		}
		else
		{
			return status;
		}
	}
	
	public boolean createTransactionEntry(TransactionBean bean) throws SQLException
	{
		Date d=bean.getDate_of_transaction();
		java.sql.Date sqldate=new java.sql.Date(d.getTime());
		
		ps=con.prepareStatement("insert into ACCOUNT_TRANSACTION_TBL values(?,?,?,?)");
		ps.setString(1,bean.getAccountNo());
		ps.setDate(2,sqldate);
		ps.setFloat(3,bean.getTransactionAmount());
		ps.setString(4,bean.getOperation());
		int x=ps.executeUpdate();
		if(x!=0)
		{
			return true;
		}
		else
			return false;
	}

}
