package com.wipro.money.service;

import java.sql.SQLException;
import java.util.Date;

import com.wipro.money.bean.AccountBean;
import com.wipro.money.bean.TransactionBean;
import com.wipro.money.dao.MoneyDAO;
import com.wipro.money.util.InsufficientBalanceException;

public class MoneyMain {
	

	public String withdraw(String accountnumber, float tr_amount) throws SQLException {

		if(accountnumber.equals(""))
		{
			return "FAILURE";
		}
		else if(tr_amount==0)
		{
			return "FAILURE";
		}
		else if(tr_amount%100!=0)
		{
			return "FAILURE";
		}
		else 
		{
			Boolean s=new MoneyDAO().validateAccount(accountnumber);
			if(s==false)
			{
				return "INVALID_ACCOUNT";
			}
			else 
			{ 
				try
				{
					float balance=new MoneyDAO().getBalance(accountnumber);
					TransactionBean tbean=new TransactionBean();
					if((balance-tr_amount)>=500)
					{
						Boolean t=new MoneyDAO().updateBalance(accountnumber, tr_amount,"withdraw");
						if(t==true)
						{
							tbean.setAccountNo(accountnumber);
							tbean.setOperation("withdraw");
							tbean.setTransactionAmount(tr_amount);
						
							tbean.setDate_of_transaction(new Date());
						}
						Boolean m=new MoneyDAO().createTransactionEntry(tbean);
						if(m==true)
							return "SUCCESS";
						
						else
						return "FAILURE";	
					}
					else 
						throw new InsufficientBalanceException();
			}
				catch(InsufficientBalanceException in)
				{
					return "Insufficient Balance";
				}	
			}
		}
	}

	public String deposit(String accountnumber, float tr_amount) throws SQLException {
	
		
		if(accountnumber.equals(""))
		{
			return "FAILURE";	
		}
		else if(tr_amount==0 || tr_amount<0f)
		{
			return "FAILURE";	
		}
		else
		{
			Boolean b=new MoneyDAO().validateAccount(accountnumber);
			if(b==false)
				return "INVALID_ACCOUNT";
			else
			{
				try{
			 Boolean t2= new MoneyDAO().updateBalance(accountnumber, tr_amount,"deposit");
			 TransactionBean tbean=new TransactionBean();
			  if(t2==true)
			  {
						tbean.setAccountNo(accountnumber);
						tbean.setOperation("deposit");
						tbean.setTransactionAmount(tr_amount);
						tbean.setDate_of_transaction(new Date());
	
			  }
			  Boolean m=new MoneyDAO().createTransactionEntry(tbean);
				if(m==true)
					return "SUCCESS";
				else
				return "FAILURE";	
			}
			catch(Exception e)
			{
				return "FAILURE";
			}
			}
		}

	}



	public static void main(String[] args) {
		

	}
}
