package com.wipro.candidate.service;

import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.dao.CandidateDAO;
import com.wipro.candidate.util.WrongDataException;

public class CandidateMain {

	

	public String addCandidate(CandidateBean candBean){
		String result = "";
			try {
				CandidateDAO cDAO = new CandidateDAO();
				
				if (candBean != null
						&& candBean.getName()!=null
						&& !candBean.getName().isEmpty()
						&& candBean.getName().length() >= 2
						&&(candBean.getM1()!=0 && candBean.getM2()!=0 && candBean.getM3()!=0)
						&& (candBean.getM1() >= 0 && candBean.getM1() <= 100)
						&& (candBean.getM2() >= 0 && candBean.getM2() <= 100)
						&& (candBean.getM3() >= 0 && candBean.getM3() <= 100)) {

					String id = cDAO.generateCandidateId(candBean.getName());
					candBean.setId(id);
					
					int m1 = candBean.getM1();
					int m2 = candBean.getM2();
					int m3 = candBean.getM3();
					int total = m1 + m2 + m3;
					if (total >= 240) {
						candBean.setResult("PASS");
						candBean.setGrade("Distinction");
					} else if (total >= 180 && total < 240) {
						candBean.setResult("PASS");
						candBean.setGrade("First Class");
					}else if (total >= 150 && total < 180) {
						candBean.setResult("PASS");
						candBean.setGrade("Second Class");
					} else if (total >= 105 && total < 150) {
						candBean.setResult("PASS");
						candBean.setGrade("Third Class");
					} else if (total < 105) {
						candBean.setResult("FAIL");
						candBean.setGrade("No Grade");
					}
					String add=cDAO.addCandidate(candBean);
					if(add.equalsIgnoreCase("SUCCESS")){
						result=id+":"+candBean.getResult();			
					
					} else{
						result="Data Incorrect";
					}
				}else{
					throw new WrongDataException();
					
				}
			} catch (Exception e) {
				System.out.println("add "+e.toString());
				result="Data Incorrect";
		}

		return result;

	}

	public ArrayList<CandidateBean> displayAll(String criteria) {
		try {
			CandidateDAO cDAO=new CandidateDAO();
			return cDAO.getByResult(criteria);
		} catch (Exception e) {
			System.out.println("list "+e.toString());
			return null;
		}
		

	}
}
