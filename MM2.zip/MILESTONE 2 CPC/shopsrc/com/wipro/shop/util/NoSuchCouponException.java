package com.wipro.shop.util;

public class NoSuchCouponException extends Exception
{
	public String toString()
	{
		return "INVALID COUPON CODE";
	}

}
