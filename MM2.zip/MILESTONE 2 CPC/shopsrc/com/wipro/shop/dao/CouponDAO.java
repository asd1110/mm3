package com.wipro.shop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.shop.bean.CouponBean;
import com.wipro.shop.util.DBUtil;

public class CouponDAO
{
	Connection con=null;
	ResultSet rs=null;
	PreparedStatement ps=null;
	Statement s=null;
	
	public CouponBean findCouponByCouponCode(String couponCode)
	{
		CouponBean cb=null;
		String sql="select * from coupons_tbl where couponcode=?";
		int flag=0;
		con=DBUtil.getDBConnection();
		try 
		{
			ps=con.prepareStatement(sql);
			ps.setString(1,couponCode);
			
			
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				cb=new CouponBean();
				cb.setCouponCode(couponCode);
				cb.setUserID(rs.getString(2));
				cb.setStatus(rs.getInt(3));
				flag=1;
			}
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
		if(flag==1)
		{
			return cb;
		}
		else
		{
			return null;
		}
	}
	
	
	public boolean updateCouponByCouponCode(String code)
	{
		String sql="update coupons_tbl set status=0 where couponcode=?";
		
		int flag=0;
		con=DBUtil.getDBConnection();
		try 
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, code);
			ps.executeUpdate();
			flag=1;
			System.out.println(flag);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
		if(flag==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public CouponBean findCouponByUserID(String userID)
	{
		CouponBean cb=null;
		String sql="select * from coupons_tbl where userid=?";
		int flag=0;
		con=DBUtil.getDBConnection();
		try 
		{
			ps=con.prepareStatement(sql);
			ps.setString(1,userID);
			
			
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				cb=new CouponBean();
				cb.setCouponCode(rs.getString(1));
				cb.setUserID(userID);
				cb.setStatus(rs.getInt(3));
				flag=1;
			}
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		if(flag==1)
		{
			return cb;
		}
		else
		{
			return null;
		}
	}
}

