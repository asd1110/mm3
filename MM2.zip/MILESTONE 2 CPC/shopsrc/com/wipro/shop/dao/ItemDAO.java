package com.wipro.shop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.wipro.shop.bean.ItemBean;
import com.wipro.shop.util.DBUtil;

public class ItemDAO 
{
	
	Connection con=null;
	ResultSet rs=null;
	List<ItemBean> list=null;
	Statement s=null;
	PreparedStatement ps=null;
	
	public List<ItemBean> findAll()
	{
		ItemBean ib=new ItemBean();
		list=new ArrayList<ItemBean>();
		con=DBUtil.getDBConnection();
		String sql="select * from items_tbl";
		try
		{
			s=con.createStatement();
			rs=s.executeQuery(sql);
			
			while(rs.next())
			{
				ib.setItemCode(rs.getString(1));
				ib.setName(rs.getString(2));
				ib.setQuantity(rs.getInt(3));
				ib.setCost(rs.getFloat(4));
				
				list.add(ib);
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return list;
	}
	
	public ItemBean findItemByItemCode(String itemCode)
	{
		ItemBean ib=null;
		con=DBUtil.getDBConnection();
		
		String sql="select * from items_tbl where itemcode=?";
		try
		{
			ib=new ItemBean();
			ps=con.prepareStatement(sql);
			ps.setString(1, itemCode);
			rs=ps.executeQuery();
			while(rs.next())
			{
				ib.setItemCode(itemCode);
				ib.setName(rs.getString(2));
				ib.setQuantity(rs.getInt(3));
				ib.setCost(rs.getFloat(4));
				
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return ib;
	}

}
