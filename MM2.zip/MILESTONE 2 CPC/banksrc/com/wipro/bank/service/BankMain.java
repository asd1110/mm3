package com.wipro.bank.service;

import java.sql.PreparedStatement;

import com.wipro.bank.bean.TransferBean;
import com.wipro.bank.dao.BankDAO;
import com.wipro.bank.util.InsufficientFundsException;

public class BankMain {
	public String checkBalance(String accountNumber){
		boolean res;
		float bal;
		String str = null;
		BankDAO dao=new BankDAO();
		res=dao.validateAccount(accountNumber);
		if(res==true){
			bal=dao.findBalance(accountNumber);
			if(bal!=-1){
				str="BALANCE IS:"+String.valueOf(bal);
			}
		}
		else{
			str="ACCOUNT NUMBER INVALID";
		}
		
		return str;
		
	}
	public String transfer(TransferBean transferBean){
		BankDAO dao=new BankDAO();
		boolean res1;
		boolean res2;
		float acbal;
		float tobal;
		float dif;
		boolean result;
		if(transferBean!=null){
			res1=dao.validateAccount(transferBean.getFromAccountNumber());
			res2=dao.validateAccount(transferBean.getToAccountNumber());
			if(res1==true && res2==true ){
				acbal=dao.findBalance(transferBean.getFromAccountNumber());
				dif=acbal-transferBean.getAmount();
				if(acbal>transferBean.getAmount()&& acbal>0){
					dao.updateBalance(transferBean.getFromAccountNumber(),dif);
					tobal=dao.findBalance(transferBean.getToAccountNumber());
					dao.updateBalance(transferBean.getToAccountNumber(), (tobal+transferBean.getAmount()));
					result=dao.transferMoney(transferBean);
					if(result==true){
						return "SUCCESS";
					}else if(result==false){
						return null;
					}
					
				}else{
					try {
						throw new InsufficientFundsException();
					} catch (InsufficientFundsException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						return e.toString();
					}
				}
					
					
			}
			else{
				return "INVALID ACCOUNT";
			}
		}else{
			return "INVALID";
		}
		
		return null;
		
	}
	public static void main(String[] args){
		
	}
}
