package com.wipro.bank.util;

public class InsufficientFundsException extends Exception {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "INSUFFICIENT FUNDS";
	}

}
