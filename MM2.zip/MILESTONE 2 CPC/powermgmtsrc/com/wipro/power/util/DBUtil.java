package com.wipro.power.util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBUtil
{
	public static Connection getDBConnection()
	{
			 String driverName="oracle.jdbc.OracleDriver";
			 String url="jdbc:oracle:thin:@localhost:1521:ORCL";
			 String username="B44576767563";
			 String password="B44576767563";
			 Connection con=null;
			try
			{
				Class.forName(driverName);
				con=DriverManager.getConnection(url,username,password);
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return con;
			
	}	
	

}
