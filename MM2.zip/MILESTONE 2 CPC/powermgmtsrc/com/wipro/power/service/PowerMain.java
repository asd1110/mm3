package com.wipro.power.service;

import java.util.ArrayList;
import java.util.Iterator;

import com.wipro.power.bean.PowerRateBean;
import com.wipro.power.bean.ReadingBean;
import com.wipro.power.dao.PowerRateDAO;
import com.wipro.power.dao.ReadingDAO;


public class PowerMain 
{
	
	public String generateBill(ReadingBean readingBean)
	{
		
		if(readingBean==null||readingBean.getPastReading()>readingBean.getPresentReading())
		{
			return "INVALID";
			
		}
		
		if(!readingBean.getType().equals("House")||!readingBean.getType().equals("Mall")||!readingBean.getType().equals("Shop"))
		{
			return "INVALID TYPE";
		}
		int units=readingBean.getPresentReading()-readingBean.getPastReading();
		readingBean.setUnitsUsed(units);
		
		PowerMain ob=new PowerMain();
		float amt=ob.calculateAmount(readingBean.getUnitsUsed(),readingBean.getType());
		
		readingBean.setAmount(amt);
		
		ReadingDAO rdao=new ReadingDAO();
		String res=rdao.createReading(readingBean);
		
		
		if(res.equals("FAIL"))
		{
			return "FAIL";
		}
		
		return "BILL AMOUNT:"+amt;
	}
	
	public float calculateAmount(int unitsUsed, String type)
	{
		float amtpay=0;
		float sl1,sl2,sl3;
		
		PowerRateDAO tdao=null;
		PowerRateBean pb=null;
		switch(type)
		{
			case "House":
				 
				tdao=new PowerRateDAO();
			     pb=tdao.findRateByType(type);
				
				 sl1=pb.getSlabRate1();
				 sl2=pb.getSlabRate2();
				 sl3=pb.getSlabRate3();
				 
				 if(unitsUsed<=25)
				 {
					 amtpay=unitsUsed*sl1;
				 }
				 
				 if(unitsUsed>25&&unitsUsed<=50)
				 {

					 amtpay=25*sl2+(unitsUsed-25)*sl2;
				 }
				 
				 if(unitsUsed>50)
				 {

					 amtpay=25*sl2+25*sl2+(unitsUsed-50)*sl3;
				 }			 
				 break;
				
			case "Shop":
				
				 tdao=new PowerRateDAO();
				 pb=tdao.findRateByType(type);
				
				 sl1=pb.getSlabRate1();
				 sl2=pb.getSlabRate2();
				 sl3=pb.getSlabRate3();
				 if(unitsUsed<=25)
				 {
					 amtpay=unitsUsed*sl1;
				 }
				 
				 if(unitsUsed>25&&unitsUsed<=50)
				 {

					 amtpay=25*sl2+(unitsUsed-25)*sl2;
				 }
				 
				 if(unitsUsed>50)
				 {

					 amtpay=25*sl2+25*sl2+(unitsUsed-50)*sl3;
				 }
				 
				break;
				
			case "Mall":
				
				 tdao=new PowerRateDAO();
				 
				 pb=tdao.findRateByType(type);
				
				 sl1=pb.getSlabRate1();
				 sl2=pb.getSlabRate2();
				 sl3=pb.getSlabRate3();
				 if(unitsUsed<=25)
				 {
					 amtpay=unitsUsed*sl1;
				 }
				 
				 if(unitsUsed>25&&unitsUsed<=50)
				 {

					 amtpay=25*sl2+(unitsUsed-25)*sl2;
				 }
				 
				 if(unitsUsed>50)
				 {

					 amtpay=25*sl2+25*sl2+(unitsUsed-50)*sl3;
				 }
				 
				break;
		}
		return amtpay;
	}
	
	
	public ArrayList<ReadingBean> viewAllBills(String month,String year)
	{
		ArrayList<ReadingBean> ar=null;
		ReadingDAO rdao=new ReadingDAO();
		ar=rdao.viewAllBillsByMonth(month, year);
		Iterator<ReadingBean> i=ar.iterator();
		ReadingBean rdb=null;
		
		
		while(i.hasNext())
		{
		 	 rdb=new ReadingBean();
			 rdb=i.next();
			 
			 
			 ar.add(rdb);
			 return ar;
		}
		return null;
	}
	
	public static void main(String[] args) 
	{
		
	}

}
