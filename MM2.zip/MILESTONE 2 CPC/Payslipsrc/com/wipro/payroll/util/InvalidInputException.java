package com.wipro.payroll.util;


public class InvalidInputException extends Exception {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String result=null;
		
		//Write your code here
		
		return "INVALID INPUT"; 
	}

}
