package com.wipro.payroll.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	public static Connection getDBConnection() throws ClassNotFoundException
	{
		Connection con=null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");	
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","B2376505","B2376505");
			System.out.println("connected");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	return con;
	}
}
