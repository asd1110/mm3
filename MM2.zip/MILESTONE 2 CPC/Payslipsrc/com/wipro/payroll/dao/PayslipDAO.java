package com.wipro.payroll.dao;

//import com.wipro.candidate.bean.CandidateBean;
//import com.wipro.candidate.util.DBUtil;
import com.wipro.payroll.bean.PayslipBean;
import com.wipro.payroll.util.DBUtil;

import  java.sql.*;

public class PayslipDAO {
	public String createPayslip(PayslipBean payslipBean)
	{
		String result="";
		
				try
		{
			Connection  con=DBUtil.getDBConnection(); 
			PreparedStatement pst=con.prepareStatement("insert into  PAYSLIP_TABLE values(?,?,?,?,?,?,?,?)");
		//	PayslipBean payslipBean=new PayslipBean();
			pst.setString(1,payslipBean.getEmployeeId());
			pst.setString(2,payslipBean.getMonth());
			pst.setString(3,payslipBean.getYear());
			pst.setDouble(4,payslipBean.getBasic());
			pst.setDouble(5,payslipBean.getDa());
			pst.setDouble(6,payslipBean.getHra());
			pst.setDouble(7,payslipBean.getPf());
			pst.setDouble(8,payslipBean.getNetSalary());
			int a=pst.executeUpdate();
			if(a==1)
			{
				return "SUCCESS";
			}
			else
			{
				return "FAILURE";
			}
			
		}catch(Exception e)
		{
			return "FAILURE";
		}
	
		//return result;
		
	}
	
	public boolean payslipExists(String empID,String month,String year)
	{
		boolean flag=false;
		try
		{
			Connection  con=DBUtil.getDBConnection();
			PreparedStatement s=con.prepareStatement("select * from  PAYSLIP_TABLE where EMPId=? and MONTH=? and YEAR=?");

			s.setString(1,empID);
			s.setString(2,month);
			s.setString(3,year);
		//ResultSet sd=s.executeQuery();
			int sd=s.executeUpdate();

if(sd==1)
{
	flag=true;
}
else
{
	flag=false;
}
		}catch(Exception e)
		{
			return flag;
		}
				return flag;
	
}
}
