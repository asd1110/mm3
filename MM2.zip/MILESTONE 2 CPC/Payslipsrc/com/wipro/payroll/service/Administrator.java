package com.wipro.payroll.service;


import com.wipro.payroll.bean.PayslipBean;
import com.wipro.payroll.dao.PayslipDAO;
import com.wipro.payroll.util.InvalidInputException;

public class Administrator {
	PayslipDAO pda=new PayslipDAO();

	public String addPayslip(PayslipBean payslipBean)
	{
		String result="";
				try{
			if(payslipBean==null || payslipBean.getEmployeeId()==null ||payslipBean.getMonth()==null||payslipBean.getBasic()==0.0 ||payslipBean.getDa()==0.0 ||payslipBean.getHra()==0.0)
			{
				throw (new InvalidInputException());
			}
			
			
		}catch(InvalidInputException e)
		{
			
		return	e.toString();
		}
			if(payslipBean!=null)
			{
				
				Boolean b=pda.payslipExists(payslipBean.getEmployeeId(),payslipBean.getMonth(),payslipBean.getYear());
				
				
				if(b==true)	
				{
					result="ALREADY EXISTS";
				}
				else
				{
					
				
				Administrator ad=new Administrator();
				Double p=ad.computePF(payslipBean.getBasic());
				payslipBean.setPf(p);
				Double  d=ad.computeNetSalary(payslipBean.getBasic(),payslipBean.getHra(),payslipBean.getDa(),payslipBean.getPf());
				payslipBean.setNetSalary(d);
				if(pda.createPayslip(payslipBean)=="SUCCESS")
				{
					result="SUCCESS"+":"+payslipBean.getEmployeeId();
				}
				else
				{
					//Administrator ad=new Administrator();
					result="SUCCESS"+":"+payslipBean.getEmployeeId();
				}
}
				}
		
		return result;
	}
	public double computeNetSalary(double basicPay,double HRA,double DA,double PF)
	{
		double sal=0.0;
		sal=basicPay+HRA+DA- PF;
		return sal;
	}
	public double computePF(double basicPay)
	{
		double pf=0.0;
		pf=0.1*basicPay;
		return pf;
	}
	public static void main(String[] args) {
		Administrator admin=new Administrator();
		PayslipBean payslipBean=new PayslipBean();
		payslipBean.setEmployeeId("JA1234");
		payslipBean.setMonth("FEB");
		payslipBean.setYear("2017");
		payslipBean.setBasic(35000);
		payslipBean.setDa(4500);
		payslipBean.setHra(10000);
		System.out.println(admin.addPayslip(payslipBean));
	}
}
