package com.wipro.pan.util;

public class InvalidRequestException {

	public String toString(){
		return "Invalid Request";
	}
}
