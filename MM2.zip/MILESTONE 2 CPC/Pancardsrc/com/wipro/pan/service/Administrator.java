package com.wipro.pan.service;

import java.util.Date;

import com.wipro.pan.bean.PANBean;
import com.wipro.pan.dao.PanDAO;

public class Administrator {

	public String newRequest(PANBean panBean)
	{
		Date currentdate=new Date();
		if(panBean==null)
		{
			return "Invalid Request";
		}
		else if(panBean.getLocation()==null)
		{
			return "Invalid Request";
		}
		else if(panBean.getRequest_date()==null)
		{
			return "Invalid Request";
		}
		else if(panBean.getName()==null)
		{
			return "Invalid Request";
		}
		else if(panBean.getRequest_date().compareTo(currentdate)!=0)
		{
			return "Invalid Date";
		}
		else if(panBean.getPhno().length()!=10)
		{
			return "Invalid PhoneNo";
		}
		else
		{
			PanDAO pd=new PanDAO();
			String id=pd.genPANID(panBean.getLocation(), panBean.getPhno());
			panBean.setPanid(id);
			Date dd=pd.genDispatchDate(panBean.getRequest_date());
			panBean.setDispatch_date(dd);
			String res=pd.processRequest(panBean);
			return res;
		}
		
	}
}
