package com.wipro.pan.main;

import java.util.Date;

import com.wipro.pan.bean.PANBean;
import com.wipro.pan.service.Administrator;

public class MainClass {
 
	public static void main(String[] args)
	{
		Administrator a= new Administrator();
		PANBean p=new PANBean();
		p.setName("komal");
		p.setLocation("nagpur");
		p.setPhno("7350588803");
		p.setRequest_date(new Date());
		String stat=a.newRequest(p);
		System.out.println(stat);
		
	}
}
