package com.wipro.pan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.wipro.pan.bean.PANBean;
import com.wipro.pan.util.DBUtil;

public class PanDAO {

	public String processRequest(PANBean panBean)
	{
		Connection con1=DBUtil.getDatabaseConnectivity();
		
		try {
			PreparedStatement ps=con1.prepareStatement("insert into PAN_TAB values(?,?,?,?,?,?)");
			ps.setString(1, panBean.getPanid());
			ps.setString(2, panBean.getName());
			ps.setString(3, panBean.getLocation());
			ps.setLong(4, Long.parseLong(panBean.getPhno()));
			ps.setDate(5, new java.sql.Date(panBean.getRequest_date().getTime()));
			ps.setDate(6, new java.sql.Date(panBean.getDispatch_date().getTime()));
			int rs=ps.executeUpdate();
			if(rs>0)
			{
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
				String d=sdf.format(panBean.getDispatch_date());
				String status=(d+":"+panBean.getPanid());
				return status;
			}
			else
			{
				return "FAIL";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return "FAIL";
		}
		
	}
	
	public String genPANID(String location,String phone_no)
	{
		Connection con2=DBUtil.getDatabaseConnectivity();
		int s1=0;
		String res="";
		try {
			PreparedStatement ps=con2.prepareStatement("select PAN_ID_SEQ.NEXTVAL from dual");
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				s1=rs.getInt(1);
			}
			String s2=location.substring(0, 2).toUpperCase();
			res=s1+s2+phone_no.charAt(phone_no.length()-1)+"";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	public Date genDispatchDate(Date RequestDate)
	{
		Calendar c=Calendar.getInstance();
		c.setTime(RequestDate);
		c.add(Calendar.DATE,5);
		Date d=c.getTime();
		return d;
	}
}
