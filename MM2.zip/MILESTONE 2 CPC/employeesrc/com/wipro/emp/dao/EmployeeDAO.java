package com.wipro.emp.dao;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.wipro.emp.util.*;
import com.wipro.emp.bean.EmployeeBean;
import com.wipro.emp.util.DBUtil;

public class EmployeeDAO {

	Connection conn=DBUtil.getConnection();
	PreparedStatement ps;
	ResultSet rs;
	
	public String createEmployee(EmployeeBean empBean) throws SQLException, ParseException
	{
		String date="18-01-1994";
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		java.util.Date utildate=sdf.parse(date);
		
		ps=conn.prepareStatement("insert into Employee_table values (?,?,?,?,?)");
		ps.setString(1,empBean.getEmpId());
		ps.setString(2,empBean.getEmpName());
		ps.setDate(3,new java.sql.Date(utildate.getTime()));
		ps.setString(4,empBean.getGender());
		ps.setFloat(5,empBean.getSalary());
		int x=ps.executeUpdate();
		System.out.println(x);
		if(x!=0)
		{
			return "Success";
		}
		else 
			return "Fail";
	}
	
	public EmployeeBean findByID(String id) throws SQLException
	{
		EmployeeBean empBean=null;
		ps=conn.prepareStatement("Select * from Employee_table where empid=?");
		ps.setString(1,id);
		rs=ps.executeQuery();
		 
		if(rs.next())
		{
			empBean=new EmployeeBean();
			empBean.setEmpName(rs.getString(2));
			java.util.Date utildate=new java.util.Date(rs.getDate(3).getTime());
			
			empBean.setDateOfBirth(utildate);
			empBean.setEmpId(rs.getString(1));
			empBean.setGender(rs.getString(4));
			empBean.setSalary(rs.getFloat(5));
			return empBean;
			//System.out.println(rs.getString(1)+""+rs.getString(2)+""+date+""+rs.getString(4)+""+rs.getFloat(5));
		}
		else
		{// empBean=null;
			return empBean;}
	}
	
	public int generateNumber() throws SQLException
	{
		ps=conn.prepareStatement("Select employeeid_seq.NEXTVAL from Dual");
		rs=ps.executeQuery();
		rs.next();
		return Integer.parseInt(rs.getString(1));
	}
	
}
