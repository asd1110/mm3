package com.wipro.emp.util;

public class InvalidInputException extends Exception {

	public String toString()
	{
		return "Invalid Data in Input";
	}
	
}
