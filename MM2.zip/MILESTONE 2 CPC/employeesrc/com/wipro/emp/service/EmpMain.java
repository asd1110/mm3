package com.wipro.emp.service;

import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.wipro.emp.bean.EmployeeBean;
import com.wipro.emp.dao.EmployeeDAO;
import com.wipro.emp.util.InvalidInputException;

public class EmpMain {

	public void addEmployee(EmployeeBean empBean) throws SQLException, ParseException
	{
		try
		{
			if(empBean==null || empBean.getSalary()==0.0f || empBean.getDateOfBirth()==null || empBean.getGender().equals("null") || empBean.getEmpName()==null || empBean.getEmpName().length()<2)
			{
				throw new InvalidInputException();
			}
			else
				
			{
				EmployeeDAO ed=new EmployeeDAO();
				int id=ed.generateNumber();
				String s=empBean.getEmpName().substring(0,2)+id;
				System.out.println(s);
				empBean.setEmpId(s);
				
				String s1=ed.createEmployee(empBean);
				if(s1.equals("Success"))
				{
					System.out.println("Employee with ID 1001  is stored successfully");
				}
				else
				{
					System.out.println("Error in inserting");
				}
			}	
		}
		catch(InvalidInputException in)
		{
			System.out.println(in);
		}
	}
	
	public void viewEmployeeByID(String EmployeeID) throws SQLException
	{
		EmployeeDAO ed=new EmployeeDAO();
		EmployeeBean empBean=ed.findByID(EmployeeID);
		if(empBean==null)
		{
			System.out.println("Employee  details not available");
		}
		else
		{
			System.out.println("Employee id:"+empBean.getEmpId());
		    System.out.println("Employee name:"+empBean.getEmpName());
		    System.out.println("Employee gender:"+empBean.getGender());
		    System.out.println("Employee dob:"+empBean.getDateOfBirth());
		    System.out.println("Employee salary:"+empBean.getSalary());
		}
	}

	public static void main(String[] args) throws ParseException,SQLException
	{
		EmpMain em=new EmpMain();
		EmployeeBean empBean=new EmployeeBean();
		empBean.setEmpName("Ashita");
		empBean.setGender("Female");
		empBean.setSalary(1000.08f);
		
		String dob="18-01-1994";
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		Date d=sdf.parse(dob);
		empBean.setDateOfBirth(d);
		//em.addEmployee(empBean);
		em.addEmployee(empBean);
		em.viewEmployeeByID("AS1000");
	}
	
	
	
}
