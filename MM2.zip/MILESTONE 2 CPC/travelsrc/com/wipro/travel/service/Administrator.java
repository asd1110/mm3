package com.wipro.travel.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import com.wipro.travel.bean.TourPlanBean;
import com.wipro.travel.bean.TravelsBean;
import com.wipro.travel.dao.TravelsDAO;
import com.wipro.travel.tour.TourPlanDAO;
import com.wipro.travel.util.InvalidInputException;

public class Administrator {

	public String addTravel(TravelsBean travelBean) throws SQLException
	{
		try
	{
			if(travelBean==null)
			{
				return "null";
			}
			long len=(travelBean.getContactNo()+"").length();
			if(travelBean.getContactNo()==0 || travelBean.getContactNo()<0 || len!=10 )
			{
				
				return "INVALID CONTACT";
			}
			if(travelBean.getTravelsName()=="" || travelBean.getTravelsName()==null || travelBean.getTravelsName()==" ")
			{
				throw new InvalidInputException();
			}	
	}
		catch(InvalidInputException in)
		{
		   return null;	
		}
		TravelsDAO tr=new TravelsDAO();
		String s1=tr.insertTravels(travelBean.getTravelsName());
		return s1;
	}
	
	public int viewTourTravels(int travelsNo) throws SQLException
	{
		ArrayList<TourPlanBean> al1=new ArrayList<TourPlanBean>();
		TourPlanDAO plan=new TourPlanDAO();
		al1=plan.fetchTravel(travelsNo);
		
			for(int i=0;i<al1.size();i++)
			{
				TourPlanBean tpb=al1.get(i);
				System.out.println(tpb.getTravels().getTravelsName());
				System.out.println(tpb.getTravels().getTravelsNo());
				System.out.println(tpb.getTravels().getContactNo());
				System.out.println(tpb.getBudget());
				System.out.println(tpb.getCityName());
				System.out.println(tpb.getTotalDays());
				//System.out.println(al1.get(i).getCityName()+""+al1.get(i).getBudget()+""+al1.get(i).getTotalDays()+""+al1.get(i).getTravels().getTravelsName()+""+al1.get(i).getTravels().getTravelsNo()+""+al1.get(i).getTravels().getContactNo());	
			}
		System.out.println("size is"+al1.size());
		return al1.size();
		
	}
	
	public static void main(String[] args) throws SQLException
	{
		TravelsBean tb=new TravelsBean();
		tb.setContactNo(9876543210L);
		tb.setTravelsName("ITDC");
		Administrator ad=new Administrator();
		System.out.println(ad.addTravel(tb));
		System.out.println(ad.viewTourTravels(2001));
		System.out.println(new TourPlanDAO().updateTravel(2002,"Paris"));

	}
	
	
	
}
