package com.wipro.travel.tour;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.wipro.travel.bean.TourPlanBean;
import com.wipro.travel.bean.TravelsBean;
import com.wipro.travel.dao.TravelsDAO;
import com.wipro.travel.util.DBUtil;

public class TourPlanDAO {

	PreparedStatement ps;
	ResultSet rs;
	Connection  conn=DBUtil.getdbConnection();
	
	public ArrayList<TourPlanBean> fetchTravel(int travelsNo) throws SQLException
	{
		ArrayList<TourPlanBean> al=new ArrayList<TourPlanBean>();
		TourPlanBean tourPlanBean=null;
		ps=conn.prepareStatement("Select * from TourPlanTable where travelsNo=?");
		ps.setInt(1,travelsNo);
		rs=ps.executeQuery();
		while(rs.next())
		{
			tourPlanBean=new TourPlanBean();
			tourPlanBean.setBudget(rs.getInt(4));
			tourPlanBean.setCityName(rs.getString(2));
			tourPlanBean.setTotalDays(rs.getInt(3));
			TravelsDAO traveldao=new TravelsDAO();
			TravelsBean bean=traveldao.getTravels(travelsNo);
			tourPlanBean.setTravels(bean);
			
			al.add(tourPlanBean);
			
		}
		if(al.size()==0)
		{
		 return null;	
		}
		else
		return al;
		
		
	}
	
	public int updateTravel(int travelsNo, String cityName) throws SQLException
	{
		ps=conn.prepareStatement("Update TourPlanTable set cityName=? where travelsNo=? ");
		ps.setString(1,cityName);
		ps.setInt(2,travelsNo);
		int a=ps.executeUpdate();
		if(a<0)
		{
			return a;
		}
		else
			return 0;
		
	}
	

	
	
	
}
