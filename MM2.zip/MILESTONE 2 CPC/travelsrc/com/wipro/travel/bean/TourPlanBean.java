package com.wipro.travel.bean;

public class TourPlanBean {

	private String cityName;
	private int totalDays;
	private TravelsBean travels;
	private float budget;
	
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public int getTotalDays() {
		return totalDays;
	}
	public void setTotalDays(int totalDays) {
		this.totalDays = totalDays;
	}
	public TravelsBean getTravels() {
		return travels;
	}
	public void setTravels(TravelsBean travels) {
		this.travels = travels;
	}
	public float getBudget() {
		return budget;
	}
	public void setBudget(float budget) {
		this.budget = budget;
	}
	
}
