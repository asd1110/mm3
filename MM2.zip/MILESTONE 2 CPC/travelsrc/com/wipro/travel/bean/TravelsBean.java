package com.wipro.travel.bean;

public class TravelsBean {

	private int travelsNo;
	private String travelsName;
	private long contactNo;
	
	public int getTravelsNo() {
		return travelsNo;
	}
	public void setTravelsNo(int travelsNo) {
		this.travelsNo = travelsNo;
	}
	public String getTravelsName() {
		return travelsName;
	}
	public void setTravelsName(String travelsName) {
		this.travelsName = travelsName;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	
}
