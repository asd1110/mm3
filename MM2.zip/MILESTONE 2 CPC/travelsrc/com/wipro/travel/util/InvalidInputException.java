package com.wipro.travel.util;

public class InvalidInputException extends Exception{

	public String tostring()
	{
		return  "Invalid Data";
	}
	
}
