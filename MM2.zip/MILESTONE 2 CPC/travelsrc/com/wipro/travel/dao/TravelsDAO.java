package com.wipro.travel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.wipro.travel.bean.TravelsBean;
import com.wipro.travel.util.DBUtil;

public class TravelsDAO {

	PreparedStatement ps;
	ResultSet rs;
	Connection conn=DBUtil.getdbConnection();
	
	public TravelsBean getTravels(int travelsNo) throws SQLException
	{
		TravelsBean travelBean=null;
		ps=conn.prepareStatement("Select * from TravelsTable where travelsNo=?");
		ps.setInt(1,travelsNo);
		rs=ps.executeQuery();
		if(rs.next())
		{
			travelBean=new TravelsBean();
			
			
			travelBean.setTravelsNo(rs.getInt(1));
			travelBean.setTravelsName(rs.getString(2));
			travelBean.setContactNo(rs.getLong(3));
			return travelBean;
	     }
		else
	return travelBean;
	}
	
	
	
	public int generateNumber() throws SQLException
	{
		ps=conn.prepareStatement("select travel_seq.NEXTVAL from Dual ");
		rs=ps.executeQuery();
		rs.next();
		return Integer.parseInt(rs.getString(1));
		
	}
	public String insertTravels(String travelsName) throws SQLException
	{
		ps=conn.prepareStatement("insert into TravelsTable (travelsNo,travelsName) values(?,?)");
		TravelsDAO trdao=new TravelsDAO();
		int num=trdao.generateNumber();
		ps.setInt(1, num);
		ps.setString(2,travelsName);
	    int r=ps.executeUpdate();
		if(r!=0)
		{
		  return "SUCCESS";	
		}
		else
		return "FAIL";
		
	}
}